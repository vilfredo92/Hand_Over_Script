#!/usr/bin/env python
# coding: utf-8
import requests
import time
import datetime
from   prettytable import PrettyTable
#from   docx import Document 
""""
Vilfredo Jordan Handanga Marcelo-2024
Hand Over Automation
"""
# Define the QRadar server and API token
QRADAR_API_URL= "https://192.168.26.70/api/siem/offenses"
QRADAR_DOMINIOS="https://192.168.26.70/api/config/domain_management/domains"
QRADAR_API_TOKEN = "a1fbe1ac-1554-4006-9ac0-7fe74a1af015"

# Convert the desired date and time to Unix timestamp (in milliseconds)
# Example: Fetch offenses between '2023-09-01 00:00:00' and '2023-09-01 23:59:59'

#Introduzir parametros a partir do teclado.

data_inicial=''
data_final=''


start_time = int(time.mktime(time.strptime(input("Introduza a data inicial:"), '%Y-%m-%d %H:%M:%S'))) * 1000 
end_time = int(time.mktime(time.strptime(input("Introduza a data final:"), '%Y-%m-%d %H:%M:%S'))) * 1000

print('end_time=',end_time)
#print('\n')
print('start_time',start_time)

# Headers with Authorization
headers = {
    'SEC':QRADAR_API_TOKEN,
    'Accept': 'application/json'
}

# Define query parameters for time filtering
params = {
    'filter': f'start_time>{start_time} and start_time<{end_time}'
}

#Classe Dominio
class Dominio:

 def __init__(self,nome,cod,ofs,fech,rep,pend):

    self.nome = nome
    self.cod = cod
    self.ofs=ofs
    self.fech=fech
    self.rep=rep
    #self.aber=aber
    self.pend=pend

 def ini_of(self):
    self.ofs=0

 def somar(self):
    self.ofs+=1

 def sho(self):
    print(self.nome)

 def setOf(self,of):
     self.ofs=of  

# Make the API request-Obter Dominios

dominios_request = requests.get(QRADAR_DOMINIOS, headers=headers,verify=False)
dominios_request=dominios_request.json()

t=len(dominios_request)
g=[] #Lista para armazenar os domínios
i=0
    
#print(w)

#print(dominios_request)


print('\n')
#print('T=',t)
for d in dominios_request:
    #print('ID:',d['id'],d['name'])
    g.append(Dominio(d['name'],d['id'],0,0,0,0)) #(self,nome,cod,ofs,aber,fech,rep):
    i+=1

   
#print('Nome:',g[8].ofs)

print('\n')
# Make the API request-Obter as ofensas para determinado intervalo
response=requests.get(QRADAR_API_URL, headers=headers, params=params,verify=False)

abertas=0
fechadas=0
reportadas=0
pendentes=0

of=0;#total
# Check if the request was successful
if response.status_code == 200:
    offenses = response.json()  # Parse the JSON response
    if offenses:
        print(f"Retrieved {len(offenses)} offenses.")
        for offense in offenses:
            of+=1
            if offense['status']=='CLOSED':
                fechadas+=1
            #if offense['status']=='OPEN':
             #   abertas+=1
            if offense['assigned_to']!='soc' and offense['assigned_to']!='NONE':
                reportadas+=1
            if offense['assigned_to']!='soc' and offense['assigned_to']!='NONE' and offense['status']=='OPEN':
                pendentes+=1    
             

           # print(f"Offense ID: {offense['id']}, Domain_ID: {offense['domain_id']}, Start Time: {offense['start_time']}")
            
    else:
        print("Sem ofensas no intervalo introduzido.")
else:
    print(f"Falha ao tentar obter offensas. Status code: {response.status_code}, Error: {response.text}")

print('\n')
print('Detecao de Ofensas:')
of_tab=PrettyTable()
of_tab.field_names = ["Nº de Ofensas","Fechadas","Reportadas","Pendentes"]

of_tab.add_row([of,fechadas,reportadas,pendentes],divider=True)
print('\n')
print(of_tab) 


def contar_ids(g,pos,ofs,id_):
    cont=0
    for f in ofs:
     #print(f['domain_id'],id_)
     if f['domain_id']==id_:
        #if f['status']=='OPEN':
         #   g[pos].aber+=1
        if f['status']=='CLOSED':
            g[pos].fech+=1
        if f['assigned_to']!='soc' and f['assigned_to']!='NONE':
            g[pos].rep+=1
        if f['assigned_to']!='soc' and f['assigned_to']!='NONE' and f['status']=='OPEN':
            g[pos].pend+=1    
            



    g[pos].ofs+=1
    return cont    

#Contar as ofensas de cada dominio

print('\n')
l=len(g)
#print('L:',l)
#g[2].setOf(100)
#print(g[2].ofs)
pos_dominio=0
c=0
id_=0

g[0].nome='DEFAULT DOMAIN'

while pos_dominio < l:
   # print('Nome:',g[pos_dominio].nome,'codigo:',g[pos_dominio].cod)
    id_=g[pos_dominio].cod
    c=contar_ids(g,pos_dominio,offenses,id_) #passar o objecto domain na função
    #print('C=',c)
    pos_dominio+=1


#print('Dominio:',g[2].nome,',Total:',g[2].ofs,',Abertas:',g[2].aber,',Fechadas',g[2].fech)    

dom=PrettyTable()
dom.field_names = ["Dominio","Nº de Ofensas","Fechadas","Abertas","Reportadas"]

#o_tabela.add_row([of['id'],of['description'],of['assigned_to'],of['status'],lpd,of['last_persisted_time']],divider=True)

d=0
while d < len(g):
    dom.add_row([g[d].nome,g[d].ofs,g[d].fech,g[d].pend,g[d].rep],divider=True)
    d+=1

#print('\n')  
print('Detecao de Ofensas-Por Dominio:') 
print(dom)